package application;

public class Carte {
    private int id;
    
    private boolean faceVisible;
    
    public Carte(int id) {
        this.id = id;
        this.faceVisible = false;
    }

    public int getId() {
        return id;
    }
}

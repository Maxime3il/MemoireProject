package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class MemoireController implements Initializable {
	private ObservableList<String> list = FXCollections.observableArrayList("Facile", "Normal", "Difficile");
	
	@FXML
	private Button bouttonJouer;
	
	@FXML
	private Label labelDifficulte;
	
	@FXML
	private Button btnFerme;
	
	@FXML
	private ComboBox<String> comboBoxDifficulte;
	
	@FXML
	public void lancerJeu(ActionEvent evt) {
		try {
			FXMLLoader fxmlLoader;
			if (comboBoxDifficulte.getValue().equals("Difficile")) {
                fxmlLoader = new FXMLLoader(getClass().getResource("MemoireVueDifficile.fxml"));
            } else if (comboBoxDifficulte.getValue().equals("Facile")) {
                fxmlLoader = new FXMLLoader(getClass().getResource("MemoireVueFacile.fxml"));
            } else {
                fxmlLoader = new FXMLLoader(getClass().getResource("MemoireVue2.fxml"));
            }
			
			Parent root1 = (Parent) fxmlLoader.load();
			Stage stage = new Stage();
	        stage.initStyle(StageStyle.UNDECORATED);
			stage.setScene(new Scene(root1,888,918));  
			stage.show();
		} catch(Exception e) {
			e.printStackTrace();
			System.out.println("Impossible de charger la seconde window");
		}
	}

	public void initialize(URL arg0, ResourceBundle arg1) {
		comboBoxDifficulte.setItems(list);
		comboBoxDifficulte.getSelectionModel().selectFirst();

		btnFerme.setOnAction((ActionEvent event) -> {
            Platform.exit();
        });
	}
	
	@FXML
	public void choisirDifficulte(ActionEvent evt) {
		String s = comboBoxDifficulte.getSelectionModel().getSelectedItem();
		labelDifficulte.setText(s);
	}
	
}

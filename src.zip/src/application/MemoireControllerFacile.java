package application;

import java.util.Collections;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.util.Duration;

public class MemoireControllerFacile {
	
	
    @FXML private Button resetButton;
    @FXML private Button button1;
    @FXML private Button button2;
    @FXML private Button button3;
    @FXML private Button button4;
    
    @FXML private Label timerLabel;
    
    @FXML private Button btnPrincipal;

    private Timeline timeline;
    private Integer timeSeconds = 30;
    
    private int nbrPaire = 2;
    
    private int cartePremiereId;
    
    @FXML private Label labelScore;
    private int nbrScore = 0;
    
    private ObservableList<Carte> cartes = FXCollections.observableArrayList();
    private ObservableList<Button> carteButton = FXCollections.observableArrayList();

    private Button selectedButton = null;

    @FXML
    public void initialize() {
    	//Appelle le bouton reset
    	resetButton.setOnAction(event -> resetGame());

    	//Partie déclaration des cartes et action sur boutons
    	cartes.add(new Carte(1));
    	cartes.add(new Carte(1));
    	cartes.add(new Carte(2));
    	cartes.add(new Carte(2));

        Collections.shuffle(cartes);
                
        // Ajouter les boutons � la liste des boutons de carte
        carteButton.addAll(button1, button2, button3, button4);
        
        btnPrincipal.setOnAction(event -> closeButtonAction());
        
        // Associer chaque carte avec un bouton
        for (int i = 0; i < cartes.size(); i++) {
            Button button = carteButton.get(i);
            Carte carte = cartes.get(i);
            
            // D�finir l'action �effectuer lorsqu'on clique sur un bouton
            button.setOnAction(event -> handleButton(button, carte));
        }
        
        //Partie d�claration et initialisation du timer
        timeline = new Timeline();
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.getKeyFrames().add(new KeyFrame(Duration.seconds(1), (ActionEvent event) -> {
            timeSeconds--;
            timerLabel.setText(String.format("%d:%02d", timeSeconds / 60, timeSeconds % 60));
            if (timeSeconds <= 0) {
                timeline.stop();
                showAlertPerdu();
            } else if(nbrPaire == 0) {
            	timeline.stop();
            	showAlertGagne();
            }
        }));
        timeline.play();
        
    }

    private void handleButton(Button button, Carte carte) {
        if (selectedButton == null) {
            // Premier bouton s�lectionn�
            selectedButton = button;
            selectedButton.setText(carte.getId() + "");
            cartePremiereId = carte.getId();
        } else {
            // Deuxi�me bouton s�lectionn�
            if (selectedButton == button) {
                // Le m�me bouton a �t� selectionn� deux fois
                return;
            }
            if(carte.getId() == cartePremiereId) {
            	nbrScore += 10;
            	labelScore.setText(nbrScore + "");
                button.setText(carte.getId() + ""); 
                selectedButton.setVisible(false);
                button.setVisible(false);
                button.setText(carte.getId() + "");
                selectedButton = null;
                nbrPaire -= 1;
            } else {
            	nbrScore -= 3;
            	labelScore.setText(nbrScore + "");
            	selectedButton.setText("Button");
            	button.setText("Button");
                selectedButton = null;
            }
        }
    }
    
    private void showAlertPerdu() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Fin de partie");
		alert.setHeaderText(null);
		alert.setContentText("Vous avez Perdu le temps est �coul�\nVotre score �tait de : " + nbrScore);
		alert.show();
		closeButtonAction();
    }
    
    private void showAlertGagne() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Fin de partie");
		alert.setHeaderText(null);
		alert.setContentText("Vous avez Gagn�\nVotre score est de : " + nbrScore);
		alert.show();
    }
    
    private void resetGame() {
        // Remettre le temps � 30 secondes
        timeSeconds = 30;
        timerLabel.setText("0:30");
        nbrScore = 0;
        nbrPaire = 2;
        // Remettre toutes les cartes face cach�e et activer les boutons
        for (Button button : carteButton) {
            button.setText("Button");
            button.setVisible(true);
        }
        
        // Mélanger les cartes
        Collections.shuffle(cartes);
        
        // Associer chaque carte avec un bouton
        for (int i = 0; i < cartes.size(); i++) {
            Button button = carteButton.get(i);
            Carte carte = cartes.get(i);
            
            // R�initialiser l'action � effectuer lorsqu'on clique sur un bouton
            button.setOnAction(event -> handleButton(button, carte));
        }
        
        // Red�marrer le timer
        timeline.stop();
        timeline.play();
    }
    
    @FXML
    private void closeButtonAction(){
      timeline.stop();
      Stage stage = (Stage) btnPrincipal.getScene().getWindow();
      stage.close();
    }
}
